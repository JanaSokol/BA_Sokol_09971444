<? include ("../../header.php"); ?>
<iframe src="gagui_further.html" width="100%" height="800">
<? include ("../../footer.php"); ?>
